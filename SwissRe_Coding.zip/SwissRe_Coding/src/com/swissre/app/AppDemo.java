package com.swissre.app;

import java.io.IOException;
import java.util.Map;

import com.swissre.model.Employee;
import com.swissre.service.OrgHierarchyAnalyzer;
import com.swissre.util.CsvFileReader;

public class AppDemo {
	public static void main(String[] args) {
        try {
            Map<String, Employee> employees = CsvFileReader.readEmployees("files/employees.csv");
            OrgHierarchyAnalyzer analyzer = new OrgHierarchyAnalyzer();
            analyzer.analyze(employees);
        } catch (IOException e) {
            System.err.println("Failed to read CSV file: " + e.getMessage());
        }
    }
}
