package com.swissre.util;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import com.swissre.model.Employee;

public class CsvFileReader {
	public static Map<String, Employee> readEmployees(String path) throws IOException {
        Map<String, Employee> employees = new HashMap<>();

        try (BufferedReader reader = new BufferedReader(new FileReader(path))) {
            reader.readLine(); // skip header section
            String line;
            while ((line = reader.readLine()) != null) {
                String[] tokens = line.split(",");
                String id = tokens[0];
                String firstName = tokens[1];
                String lastName = tokens[2];
                double salary = Double.parseDouble(tokens[3]);
                String managerId = tokens.length > 4 ? tokens[4] : null;

                Employee emp = new Employee(id, firstName, lastName, salary, managerId);
                employees.put(id, emp);
            }
        }

        // Build hierarchy from employees map
        for (Employee emp : employees.values()) {
            if (emp.managerId != null && employees.containsKey(emp.managerId)) {
                Employee manager = employees.get(emp.managerId);
                emp.manager = manager;
                manager.subordinates.add(emp);
            }
        }
        return employees;
    }
}
