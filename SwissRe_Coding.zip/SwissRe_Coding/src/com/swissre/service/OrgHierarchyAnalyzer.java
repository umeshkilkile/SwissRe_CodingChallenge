package com.swissre.service;

import java.util.Map;

import com.swissre.model.Employee;

public class OrgHierarchyAnalyzer {
	public void analyze(Map<String, Employee> employees) {
		for (Employee emp : employees.values()) {
			if (!emp.subordinates.isEmpty()) {
				analyzeManagerSalary(emp);
			}
		}

		for (Employee emp : employees.values()) {
			int depth = getDepth(emp);
			if (depth > 4) {
				System.out.printf("Employee %s has a reporting line too long (depth %d)\n", emp.getFullName(), depth);
			}
		}
	}

	private void analyzeManagerSalary(Employee manager) {
		double avgSubSalary = manager.subordinates.stream().mapToDouble(e -> e.salary).average().orElse(0.0);

		double lowerBound = avgSubSalary * 1.2;
		double upperBound = avgSubSalary * 1.5;

		if (manager.salary < lowerBound) {
			double diff = lowerBound - manager.salary;
			System.out.printf("Manager %s earns $%.2f less than minimum allowed (%.2f)\n", manager.getFullName(), diff,
					lowerBound);
		} else if (manager.salary > upperBound) {
			double diff = manager.salary - upperBound;
			System.out.printf("Manager %s earns $%.2f more than maximum allowed (%.2f)\n", manager.getFullName(), diff,
					upperBound);
		}
	}

	private int getDepth(Employee emp) {
		int depth = 0;
		Employee curr = emp.manager;
		while (curr != null) {
			depth++;
			curr = curr.manager;
		}
		return depth;
	}
}
