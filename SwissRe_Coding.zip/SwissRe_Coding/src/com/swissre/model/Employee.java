
package com.swissre.model;

import java.util.ArrayList;
import java.util.List;

public class Employee {

	public final String id;
	public final String firstName;
	public final String lastName;
	public final double salary;
	public final String managerId;
	public final List<Employee> subordinates = new ArrayList<>();
	public Employee manager;

	public Employee(String id, String firstName, String lastName, double salary, String managerId) {
		this.id = id;
		this.firstName = firstName;
		this.lastName = lastName;
		this.salary = salary;
		this.managerId = managerId;
	}

	public String getFullName() {
		return firstName + " " + lastName;
	}
}
